//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<wifi_hunter/WifiHunterPlugin.h>)
#import <wifi_hunter/WifiHunterPlugin.h>
#else
@import wifi_hunter;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [WifiHunterPlugin registerWithRegistrar:[registry registrarForPlugin:@"WifiHunterPlugin"]];
}

@end
