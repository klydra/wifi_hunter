//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<wifi_hunter/WiFiHunterPlugin.h>)
#import <wifi_hunter/WiFiHunterPlugin.h>
#else
@import wifi_hunter;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [WiFiHunterPlugin registerWithRegistrar:[registry registrarForPlugin:@"WiFiHunterPlugin"]];
}

@end
